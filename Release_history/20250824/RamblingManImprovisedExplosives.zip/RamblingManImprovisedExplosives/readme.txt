## Rambling Man - Improvised Explosives 
Rambling Man - Improvised Explosives lets you craft improvised versions of pipe bombs and several other explosive items in your backpack. They require more resources to craft and tend to work less consistently than their versions crafted in the workbench.

## Important Notes 

Improvised versions of pipe bombs and other explosives are indicated by the Pack Mule symbol in the bottom left of the item icon.

## Requirements
7 Days to Die v2.0 and later.