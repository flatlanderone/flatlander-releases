## Any Starting Trader - No Desert

Your starting trader is the closest trader in the biome in which you complete the Basics of Survival challenges, unless you complete in the desert biome. In that case, you will be directed to the closest trader in the other biomes.

## Requirements
7 Days to Die v2.0 and later.