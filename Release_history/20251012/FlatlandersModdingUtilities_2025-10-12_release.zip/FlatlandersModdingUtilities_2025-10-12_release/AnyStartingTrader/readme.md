## Any Starting Trader 2.3.0.3

Your starting trader is the closest trader in the biome in which you complete the Basics of Survival challenges.

## Requirements
7 Days to Die v2.0 and later.