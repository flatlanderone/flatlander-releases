## Bigger Crafting Resources Pack On Spawn

Adds to inventory a more complete crafting bundle on first spawn. See the screenshots in the images folder.

## Important notes

Make sure to have enough free inventory slots!

## Requirements

7 Days to Die v2.0 and later.