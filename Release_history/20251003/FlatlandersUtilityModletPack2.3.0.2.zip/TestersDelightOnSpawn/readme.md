## Tester's Delight On Spawn

Adds to inventory the Tester's Delight note on first spawn. Reading the note adds an assortment of dev items. See the screenshots in the images folder.

## Important notes

Make sure to have enough free inventory slots!

## Requirements
7 Days to Die v2.0 and later.