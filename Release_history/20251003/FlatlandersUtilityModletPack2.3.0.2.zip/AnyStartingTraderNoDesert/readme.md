## Any Starting Trader - No Desert

Your starting trader is the closest trader in relation to your spawn point, unless you spawn in the desert biome. In that case, you will be directed to the pine forest trader. See the screenshots in the images folder.

## Important Notes 

Edit your spawnpoints.xml to spawn in a different biome.

## Requirements
7 Days to Die v2.0 and later.