# Tier 1 Common Ranged Weapons As Intro Buried Supplies Rewards - version 2.5.1.0

## Overview
**Tier 1 Common Ranged Weapons As Intro Buried Supplies Rewards** changes the rewards for completing the Intro Buried Supplies quest. Instead of Tier 0 pipe weapons and ammo, you choose from a set of common Tier 1 ranged weapons (Double Barrel Shotgun, Hunting Rifle, Iron Crossbow, Pistol, Wooden Bow).

## Requirements
 - 7 Days to Die v2.5 and later.

## Manual installation
 1. Download the mod file.
 2. Decompress it anywhere on your hard drive.
 3. Copy the **T1CommonRangedWeaponsAsIBSRewardFLTR** folder to the 7 Days to Die Mods folder. The default location is **%APPDATA%\7DaysToDie\Mods**.

## Important notes
 1. Removing the mod is probably safe, but you should always make a backup of your game save.
 2. The mod is compatible with [Extreme Quick Start](https://www.nexusmods.com/7daystodie/mods/8856) and my other mods which modify starting quests.

## Bug reports and feature suggestions
 - [GitHub](https://github.com/flatlanderone/flatlander-releases/issues) (preferred).
 - [My channel on Guppy's Modding Server](https://discord.gg/yPFh79rq8J).
 - This mod's page on Nexus Mods.

## About this mod
 - **Author**: Flat Lander - [GitHub](https://github.com/flatlanderone/flatlander-releases) / [Nexus Mods](https://next.nexusmods.com/profile/flatlanderone)
 - **Download page**: [Tier 1 Common Ranged Weapons As Intro Buried Supplies Rewards](https://www.nexusmods.com/7daystodie/mods/9997)
 - **Initial release**: 2.5.1.0 (2026-03-30)