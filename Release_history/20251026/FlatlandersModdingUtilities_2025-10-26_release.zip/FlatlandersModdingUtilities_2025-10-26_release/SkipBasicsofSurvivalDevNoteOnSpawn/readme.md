# Skip Basics of Survival Dev Note On Spawn 2.3.0.1

## Overview

Adds to inventory the Skip Basics of Survival dev note on first spawn. Reading the note completes automatically the challenges.

It also gives you: 
- the 1000 XP you would have earned from completing the challenges,
- all the items that would have been crafted for the tutorial challenges ,- additional primitive armor pieces,
- 9 extra arrows,
- a stone shovel.

Finally, the modlet also disables the Note from the Duke tooltip and entry in Status Effects.

## Important notes

1. Do not install this mod into an existing save. 

2. Not tested in multiplayer.

3. The mod might not be compatible with mods and overhauls that modify the basic  vanilla challenges or rely on them.

## Requirements

- 7 Days to Die v2.0 and later,

- A new save. 

# Related quest mods

- [Faster Intro Buried Supplies](https://www.nexusmods.com/7daystodie/mods/8740),

- [Skip Intro Buried Supplies](https://www.nexusmods.com/7daystodie/mods/8764),

- [Skip Basics of Survival Tutorial Challenges](https://www.nexusmods.com/7daystodie/mods/8772).