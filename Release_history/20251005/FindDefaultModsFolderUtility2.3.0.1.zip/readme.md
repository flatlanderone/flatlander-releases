## 7 Days To Die Default Mods Folder Finding Utility 2.3.0.1

This is a simple batch file (\*.bat) that does two things:

1. It looks for the 7 Days To Die `Mods` folder in the default location (%APPDATA%\7DaysToDie). If it finds it, it will open it in Windows Explorer.

2. If it doesn't find, it will create it and then open it in Windows Explorer.

More about batch files: https://en.wikipedia.org/wiki/Batch_file

## Requirements

7 Days to Die v2.0 and later.