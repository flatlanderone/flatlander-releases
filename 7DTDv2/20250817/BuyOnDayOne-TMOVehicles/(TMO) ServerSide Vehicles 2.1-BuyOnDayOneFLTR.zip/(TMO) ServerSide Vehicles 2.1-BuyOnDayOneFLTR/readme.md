# Buy On Day One - TMO Vehicles

Buy On Day One - TMO Vehicles lets you buy all TMO vehicles from each trader starting on your first day in the zombie apocalypse. 

# Requirements
 [(TMO) ServerSide Vehicles](https://www.nexusmods.com/7daystodie/mods/6355).

## Important Notes 
1. If you install any of the Buy On Day One mods in an existing world, you must reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.
2. Not tested in multiplayer.
3. The mods should not affect other vehicle mods (to be confirmed).
4. Removing the mods is safe, but you should reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.
