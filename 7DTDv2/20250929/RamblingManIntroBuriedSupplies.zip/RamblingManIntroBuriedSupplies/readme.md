# White River Citizen and Intro Buried Supplies As A Single Quest (WRCIBSSQ)

1. **White River Citizen and Intro Buried Supplies As A Single Quest** lets you complete the Intro Buried Supplies quest before visiting the Trader. This lets you start regular questing immediately after visiting the Trader for the first time.

2. After completing the ***Basics of Survival*** challenges, you receive the new ***Dig up the supplies and find the Trader*** quest and are directed to the buried supplies. Once you have dug them up, you are directed to the closest Trader in the current biome.

# Important notes

1. Buried supplies will not spawn in the middle of towns and cities. Go outside of the city and wait a few seconds to fix this.

2. Not tested in multiplayer.

3. The mod is not compatible with mods and overhauls that modify the starting quest or add new starting quests.

# Requirements

- 7 Days to Die v2.0 and later.

# Bug reports and feature suggestions

- [GitHub](https://github.com/flatlanderone/flatlander-releases/issues) (preferred).

- This mod's page on Nexus Mods.

# About this mod

- **Author**: Flat Lander - [GitHub](https://github.com/flatlanderone/flatlander-releases) / [Nexus Mods](https://next.nexusmods.com/profile/flatlanderone)

- **Download page**: [White River Citizen and Intro Buried Supplies As A Single Quest](https://www.nexusmods.com/7daystodie/mods/8740)

- **Version**: 0.1.0.0

- **Initial release**: 2025-09-29 (0.1.0.0)