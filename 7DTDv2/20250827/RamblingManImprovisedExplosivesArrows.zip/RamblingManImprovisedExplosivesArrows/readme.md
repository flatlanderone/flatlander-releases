## Rambling Man - Improvised Explosives and Arrows
Rambling Man - Improvised Explosives and Arrows lets you craft in your backpack improvised versions of the following items:
- pipe bombs,
- dynamite,
- timed charges,
- exploding arrows and bolts,
- flaming arrows and bolts. 

They require more resources to craft and tend to work more randomly than their regular versions crafted in the workbench.

## Important Notes 

1. Improvised versions of explosives and arrows are indicated by the Pack Mule symbol in the bottom left of the item icon.

![image info](./images/ui_game_symbol_pack_mule.png)

2. Delete the old version of this mod.

## Requirements
7 Days to Die v2.0 and later.

## Changelog for v 0.2.0.0
- Added Improvised Flaming Crossbow Bolts.
- Updated localization for the backpack craftable Flaming Arrow. It's now "Improvised Flaming Arrow."
- Changed the Name value in modinfo.xml. 
- Added conditional loading for compatibility with future Rambling Man mods.
